
import os
import re
import boto3
import json
import requests
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.secret_key = os.urandom(24)

# --- AWS Clients ---
cognito_client = boto3.client(
    'cognito-idp',
    aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
    aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
    region_name=os.getenv('AWS_DEFAULT_REGION')
)
CLIENT_ID = os.getenv('COGNITO_CLIENT_ID')
CLIENT_SECRET = os.getenv('COGNITO_CLIENT_SECRET')
COGNITO_DOMAIN = os.getenv('COGNITO_DOMAIN')
REDIRECT_URI = os.getenv('COGNITO_REDIRECT_URI')

textract_client = boto3.client(
    'textract',
    aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
    aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
    region_name=os.getenv('AWS_DEFAULT_REGION')
)

# --- Utility Functions ---
def normalize_rut(rut_string):
    return rut_string.replace(".", "").upper() if rut_string else ""

def get_user_cognito_attributes(access_token):
    try:
        user_response = cognito_client.get_user(AccessToken=access_token)
        return {attr['Name']: attr['Value'] for attr in user_response['UserAttributes']}
    except cognito_client.exceptions.NotAuthorizedException:
        return None

def find_rut_in_text(text_lines):
    rut_pattern = re.compile(r'\b(\d{1,2}\.\d{3}\.\d{3}-[\dkK])\b')
    for line in text_lines:
        match = rut_pattern.search(line)
        if match:
            return match.group(1)
    return None

# --- Flask Routes ---
@app.route('/')
def index():
    if 'access_token' in session:
        return redirect(url_for('form'))
    return render_template('index.html')

@app.route('/login')
def login():
    cognito_login_url = f"https://{COGNITO_DOMAIN}/login?client_id={CLIENT_ID}&response_type=code&scope=openid+email+profile&redirect_uri={REDIRECT_URI}"
    return redirect(cognito_login_url)

@app.route('/callback')
def callback():
    code = request.args.get('code')
    # If there's no code, it's a post-logout redirect. Send to homepage.
    if not code:
        return redirect(url_for('index'))

    # If there IS a code, it's a login attempt. Exchange it for tokens.
    token_url = f"https://{COGNITO_DOMAIN}/oauth2/token"
    payload = {
        'grant_type': 'authorization_code',
        'client_id': CLIENT_ID,
        'client_secret': CLIENT_SECRET,
        'redirect_uri': REDIRECT_URI,
        'code': code
    }
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}

    try:
        response = requests.post(token_url, data=payload, headers=headers)
        response.raise_for_status()
        tokens = response.json()
        session['access_token'] = tokens['access_token']
        return redirect(url_for('form'))

    except requests.exceptions.RequestException as e:
        app.logger.error(f"Error al intercambiar el código por tokens: {e}")
        return f"Ocurrió un error de comunicación con Cognito: {e}", 500

@app.route('/logout')
def logout():
    # The logout URI must be the one registered in Cognito, which is the /callback URI
    logout_uri = REDIRECT_URI
    cognito_logout_url = f"https://{COGNITO_DOMAIN}/logout?client_id={CLIENT_ID}&logout_uri={logout_uri}"
    session.clear()
    return redirect(cognito_logout_url)

@app.route('/form')
def form():
    if 'access_token' not in session:
        return redirect(url_for('login'))
    return render_template('form.html')

@app.route('/upload', methods=['POST'])
def upload():
    if 'access_token' not in session:
        return jsonify({'error': 'No autorizado'}), 401

    if 'file' not in request.files or not request.files['file'].filename:
        return jsonify({'error': 'No se seleccionó ningún archivo.'})

    file = request.files['file']
    image_bytes = file.read()

    try:
        textract_response = textract_client.detect_document_text(Document={'Bytes': image_bytes})
        text_lines = [item['Text'] for item in textract_response['Blocks'] if item['BlockType'] == 'LINE']
        rut_from_image = find_rut_in_text(text_lines)

        if not rut_from_image:
            return jsonify({'error': 'No se pudo encontrar un RUT en la imagen.'})

        user_attributes = get_user_cognito_attributes(session['access_token'])
        if not user_attributes:
            return jsonify({'error': 'Tu sesión ha expirado. Por favor, inicia sesión de nuevo.', 'redirect': url_for('login')})
       
        rut_from_cognito = user_attributes.get('custom:rut', '')
        is_match = normalize_rut(rut_from_image) == normalize_rut(rut_from_cognito)
        message = 'El RUT del documento coincide con el del usuario.' if is_match else 'El RUT del documento no coincide con el del usuario.'

        return jsonify({
            'message': message,
            'rut_from_image': rut_from_image,
            'rut_from_cognito': rut_from_cognito,
            'match': is_match
        })

    except Exception as e:
        app.logger.error(f"Error al procesar el archivo: {e}")
        return jsonify({'error': 'Ocurrió un error inesperado al procesar la imagen.'}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=True)
